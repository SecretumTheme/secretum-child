=== Secretum Child ===
Contributors: SecretumTheme
Version: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

**This is the primary child theme for [Secretum Theme](https://github.com/SecretumTheme/secretum/)** - A highly customizable fluid-responsive cross-device multi-purpose WordPress theme created for both beginner and advanced WordPress users.
